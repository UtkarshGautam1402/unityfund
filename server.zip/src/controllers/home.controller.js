const home = (req, res) => {
  res.send("testing routes working...");
};

module.exports = { home };
